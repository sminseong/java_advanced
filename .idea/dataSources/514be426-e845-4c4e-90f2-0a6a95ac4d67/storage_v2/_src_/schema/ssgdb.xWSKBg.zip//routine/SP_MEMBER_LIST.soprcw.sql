create
    definer = ssg@localhost procedure SP_MEMBER_LIST()
BEGIN
    SET @sql = CONCAT('SELECT * FROM TB_MEMBER');

    PREPARE stmt FROM @sql;
    deallocate prepare stmt;
end;

