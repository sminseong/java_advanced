create
    definer = ssg@localhost procedure SP_MEMBER_INSERT(IN V_userid varchar(50), IN V_pwd varchar(50),
                                                       IN V_email varchar(50), IN V_hp varchar(20), OUT RTN_CODE int)
BEGIN
    DECLARE v_count int;

    -- 중복사용자 예외 처리
    SELECT COUNT(m_seq) INTO v_count FROM TB_MEMBER WHERE m_userid = V_userid;

    IF v_count > 0 THEN SET RTN_CODE = 100;
        ELSE
            INSERT INTO TB_MEMBER (m_userid, m_pwd, m_email, m_hp) VALUES (V_userid, V_pwd, V_email, V_hp);

            SET RTN_CODE = 200;
    END IF;
    COMMIT;
end;

