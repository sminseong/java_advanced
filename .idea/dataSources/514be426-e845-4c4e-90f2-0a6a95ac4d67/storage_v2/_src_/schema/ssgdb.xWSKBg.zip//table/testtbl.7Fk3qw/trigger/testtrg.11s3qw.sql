create definer = ssg@localhost trigger testTrg
    after delete
    on testtbl
    for each row
BEGIN
    SET @msg = '가수 그룹이 삭제됨';
end;

