create
    definer = ssg@localhost procedure name_const(IN u_name varchar(10))
BEGIN
    SELECT * FROM userTbl WHERE name = u_name;
end;

