create
    definer = ssg@localhost procedure totalSum2()
BEGIN
    DECLARE i INT;
    DECLARE result INT;
    DECLARE savepointResult INT;

    DECLARE EXIT HANDLER FOR 1264
    BEGIN
        SELECT CONCAT('INT 오버플로 직전의 합계 --> ', savepointResult);
        SELECT CONCAT('1+2+3+.....+ ', i, ' = 오버플로');
    end ;
    SET i = 1;
    SET result = 0;

    WHILE(TRUE) DO
        SET savepointResult = result;       -- 오버플로 직전의 합을 저장하기 위해
        SET result = result + i;
        SET i = i + 1;
    end while ;
end;

