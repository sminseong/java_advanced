create
    definer = ssg@localhost procedure select_user(IN u_birthyear int, IN u_height smallint)
BEGIN
    SELECT * FROM usertbl WHERE birthYear >= u_birthyear AND height > u_height;
end;

