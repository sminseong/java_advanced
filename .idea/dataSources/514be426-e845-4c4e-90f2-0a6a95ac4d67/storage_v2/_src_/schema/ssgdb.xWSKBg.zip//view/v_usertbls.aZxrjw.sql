create definer = ssg@localhost view v_usertbls as
select `ssgdb`.`usertbl`.`userID` AS `userid`, `ssgdb`.`usertbl`.`name` AS `name`, `ssgdb`.`usertbl`.`addr` AS `addr`
from `ssgdb`.`usertbl`;

