create
    definer = ssg@localhost procedure totalSum(IN i int, IN j int)
BEGIN
    DECLARE sum INT;
    DECLARE str VARCHAR(100);
    DECLARE start INT;
    DECLARE end INT;

    SET sum = 0;
    SET start = i;
    SET end = j;

    WHILE (i <= j) DO
        SET sum = sum + i;
        SET i = i + 1;
    end while ;

    SET str = concat(start, '부터 ', end, '까지의 합은 ', sum, ' 입니다.');
    INSERT INTO totalSum VALUES (str);
    SELECT * FROM totalSum;
end;

