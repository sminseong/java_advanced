create definer = ssg@localhost trigger backUserTbl_DeleteTrg
    after delete
    on usertbl
    for each row
BEGIN
    INSERT INTO backup_userTbl VALUES (OLD.userId, OLD.name, OLD.birthYear, OLD.addr,
                                       OLD.mobile1, OLD.mobile2, OLD.height, OLD.mDate, '삭제', CURDATE(), CURRENT_USER());
end;

