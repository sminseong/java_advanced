create definer = sakila@localhost view customer_list as
select `cu`.`customer_id`                                       AS `ID`,
       concat(`cu`.`first_name`, _utf8mb4' ', `cu`.`last_name`) AS `name`,
       `a`.`address`                                            AS `address`,
       `a`.`postal_code`                                        AS `zip code`,
       `a`.`phone`                                              AS `phone`,
       `sakiladb`.`city`.`city`                                 AS `city`,
       `sakiladb`.`country`.`country`                           AS `country`,
       if(`cu`.`active`, _utf8mb4'active', _utf8mb4'')          AS `notes`,
       `cu`.`store_id`                                          AS `SID`
from (((`sakiladb`.`customer` `cu` join `sakiladb`.`address` `a`
        on ((`cu`.`address_id` = `a`.`address_id`))) join `sakiladb`.`city`
       on ((`a`.`city_id` = `sakiladb`.`city`.`city_id`))) join `sakiladb`.`country`
      on ((`sakiladb`.`city`.`country_id` = `sakiladb`.`country`.`country_id`)));

