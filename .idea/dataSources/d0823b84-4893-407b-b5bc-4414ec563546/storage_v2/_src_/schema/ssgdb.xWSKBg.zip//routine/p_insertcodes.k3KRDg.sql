create
    definer = ssg@localhost procedure p_insertcodes(IN cData varchar(255), IN cTName varchar(255))
BEGIN
    -- 쿼리문 생성
    SET @strsql =  CONCAT(
            'INSERT INTO ', cTName, ' (cId , cName) ', ' SELECT COALESCE(MAX(cId),0) + 1  , ? FROM ' , cTname );

    -- 바인딩할 변수 설정
    SET @cData = cData;
    -- SET resultMsg = 'Insert Success';

    PREPARE stmt FROM @strsql;
    EXECUTE stmt using @cData;
    deallocate prepare stmt;

    -- 트랜잭션 확정
    COMMIT ;
end;

