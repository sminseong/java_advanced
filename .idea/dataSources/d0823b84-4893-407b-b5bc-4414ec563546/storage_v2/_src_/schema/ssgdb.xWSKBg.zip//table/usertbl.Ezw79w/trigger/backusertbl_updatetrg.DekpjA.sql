create definer = ssg@localhost trigger backUserTbl_UpdateTrg
    after update
    on usertbl
    for each row
BEGIN
    INSERT INTO backup_userTbl VALUES (OLD.userId, OLD.name, OLD.birthYear, OLD.addr,
                                       OLD.mobile1, OLD.mobile2, OLD.height, OLD.mDate, '수정', CURDATE(), CURRENT_USER());
end;

