create
    definer = ssg@localhost function userFunc(value1 int, value2 int) returns int
BEGIN
    RETURN value1 + value2;
end;

