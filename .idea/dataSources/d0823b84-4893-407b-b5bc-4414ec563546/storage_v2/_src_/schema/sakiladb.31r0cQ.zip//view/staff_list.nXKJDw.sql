create definer = sakila@localhost view staff_list as
select `s`.`staff_id`                                         AS `ID`,
       concat(`s`.`first_name`, _utf8mb4' ', `s`.`last_name`) AS `name`,
       `a`.`address`                                          AS `address`,
       `a`.`postal_code`                                      AS `zip code`,
       `a`.`phone`                                            AS `phone`,
       `sakiladb`.`city`.`city`                               AS `city`,
       `sakiladb`.`country`.`country`                         AS `country`,
       `s`.`store_id`                                         AS `SID`
from (((`sakiladb`.`staff` `s` join `sakiladb`.`address` `a`
        on ((`s`.`address_id` = `a`.`address_id`))) join `sakiladb`.`city`
       on ((`a`.`city_id` = `sakiladb`.`city`.`city_id`))) join `sakiladb`.`country`
      on ((`sakiladb`.`city`.`country_id` = `sakiladb`.`country`.`country_id`)));

